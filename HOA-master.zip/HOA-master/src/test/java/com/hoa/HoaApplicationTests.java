package com.hoa;



import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class HoaApplicationTests {

	@Test
	public void contextLoads() {
	}

}
